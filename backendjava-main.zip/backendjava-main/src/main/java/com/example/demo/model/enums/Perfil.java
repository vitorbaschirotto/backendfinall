package com.example.demo.model.enums;

public enum Perfil {
    ADMIN, CLIENTE, TECNICO
}
