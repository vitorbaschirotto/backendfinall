package com.example.demo.model.enums;

public enum Prioridade {
    BAIXA, MEDIA, ALTA
}
