package com.example.demo.model.enums;

public enum Status {
    ABERTO, ANDAMENTO, ENCERRADO
}
